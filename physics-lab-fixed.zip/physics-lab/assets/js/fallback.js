/*
 * Сыртқы кітапханалар (CDN) жүктелмесе, сайт істемей қалмауы үшін қосымша қорғаныс.
 * - Math.js жоқ болса: калькулятор үшін шағын ішкі есептегіш (math.evaluate / math.format).
 * - KaTeX жоқ болса: assets/vendor/katex ішіндегі жергілікті көшірме жүктеледі (index.html ішінде).
 */
(function () {
  if (window.math) return;
  const fact = (n) => { n = Math.round(n); if (n < 0 || n > 170) return NaN; let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
  const clean = (v) => Math.abs(v) < 1e-12 ? 0 : v;
  const F = {
    sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, log10: Math.log10, log: Math.log, exp: Math.exp,
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
    fact, pow: Math.pow
  };
  const extra = {};
  window.math = {
    import(o) { Object.assign(extra, o); },
    evaluate(src, scope) {
      let s = String(src);
      if (!/^[0-9a-zA-Z_+\-*/^().,\s!]*$/.test(s)) throw new Error('bad');
      s = s.replace(/(\d+(?:\.\d+)?)\s*!/g, 'fact($1)').replace(/\^/g, '**');
      s = s.replace(/\bpi\b/g, 'PI').replace(/\be\b(?!\d)/g, 'E');
      const names = Object.assign({}, F, extra, { PI: Math.PI, E: Math.E, Ans: (scope && scope.Ans) || 0 });
      const keys = Object.keys(names);
      if (/[a-zA-Z_]+/.test(s.replace(/\d+(?:\.\d+)?e[+-]?\d+/gi, '0'))) {
        const ids = s.match(/[a-zA-Z_]\w*/g) || [];
        for (const id of ids) if (!keys.includes(id)) throw new Error('bad');
      }
      const v = Function(...keys, '"use strict"; return (' + s + ');')(...keys.map(k => names[k]));
      if (typeof v !== 'number') throw new Error('bad');
      return v;
    },
    format(v, o) {
      const p = (o && o.precision) || 12;
      if (v === 0) return '0';
      const a = Math.abs(v);
      if (a < 1e-9 || a >= 1e15) return String(Number(v.toPrecision(p))).replace('e+', 'e');
      return String(Number(v.toPrecision(p)));
    }
  };
})();
